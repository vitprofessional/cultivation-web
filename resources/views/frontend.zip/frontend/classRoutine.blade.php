@extends('frontend.include')
@section('fronttitle')
Enter to learn & Leave to serve
@endsection

@section('frontcontent')
@endsection